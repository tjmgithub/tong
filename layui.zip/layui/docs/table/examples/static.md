默认风格:

<table class="layui-table">
  <colgroup>
    <col width="150">
    <col width="150">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>人物</th>
      <th>民族</th>
      <th>格言</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>孔子</td>
      <td>华夏</td>
      <td>有朋自远方来，不亦乐乎</td>
    </tr>
    <tr>
      <td>孟子</td>
      <td>华夏</td>
      <td>穷则独善其身，达则兼济天下</td>
    </tr>
  </tbody>
</table>
 
行边框表格:

<table class="layui-table" lay-skin="line">
  <colgroup>
    <col width="150">
    <col width="150">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>人物</th>
      <th>民族</th>
      <th>格言</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>孔子</td>
      <td>华夏</td>
      <td>有朋自远方来，不亦乐乎</td>
    </tr>
    <tr>
      <td>孟子</td>
      <td>华夏</td>
      <td>穷则独善其身，达则兼济天下</td>
    </tr>
  </tbody>
</table>
 
列边框表格:

<table class="layui-table" lay-skin="row">
  <colgroup>
    <col width="150">
    <col width="150">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>人物</th>
      <th>民族</th>
      <th>格言</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>孔子</td>
      <td>华夏</td>
      <td>有朋自远方来，不亦乐乎</td>
    </tr>
    <tr>
      <td>孟子</td>
      <td>华夏</td>
      <td>穷则独善其身，达则兼济天下</td>
    </tr>
  </tbody>
</table>
 
无边框表格:

<table class="layui-table" lay-skin="nob">
  <colgroup>
    <col width="150">
    <col width="150">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>人物</th>
      <th>民族</th>
      <th>格言</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>孔子</td>
      <td>华夏</td>
      <td>有朋自远方来，不亦乐乎</td>
    </tr>
    <tr>
      <td>孟子</td>
      <td>华夏</td>
      <td>穷则独善其身，达则兼济天下</td>
    </tr>
  </tbody>
</table>
 
小尺寸表格:

<table class="layui-table" lay-size="sm">
  <colgroup>
    <col width="150">
    <col width="150">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>人物</th>
      <th>民族</th>
      <th>格言</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>孔子</td>
      <td>华夏</td>
      <td>有朋自远方来，不亦乐乎</td>
    </tr>
    <tr>
      <td>孟子</td>
      <td>华夏</td>
      <td>穷则独善其身，达则兼济天下</td>
    </tr>
  </tbody>
</table>
 
大尺寸表格:

<table class="layui-table" lay-size="lg">
  <colgroup>
    <col width="150">
    <col width="150">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>人物</th>
      <th>民族</th>
      <th>格言</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>孔子</td>
      <td>华夏</td>
      <td>有朋自远方来，不亦乐乎</td>
    </tr>
    <tr>
      <td>孟子</td>
      <td>华夏</td>
      <td>穷则独善其身，达则兼济天下</td>
    </tr>
  </tbody>
</table>

开启偶数行背景色:

<table class="layui-table" lay-even>
  <colgroup>
    <col width="150">
    <col width="150">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>人物</th>
      <th>民族</th>
      <th>格言</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>孔子</td>
      <td>华夏</td>
      <td>有朋自远方来，不亦乐乎</td>
    </tr>
    <tr>
      <td>孟子</td>
      <td>华夏</td>
      <td>穷则独善其身，达则兼济天下</td>
    </tr>
    <tr>
      <td>庄子</td>
      <td>华夏</td>
      <td>朴素而天下莫能与之争美</td>
    </tr>
  </tbody>
</table>